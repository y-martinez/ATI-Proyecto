﻿=== MineCraft Icon Set ===

By: Neo-TheDragon (http://www.rw-designer.com/user/24536)

Download: http://www.rw-designer.com/icon-set/minecraft

Author's decription:

MineCraft Icons!

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.